// ─────────────────────────────────────────────
//  VidXJobsNavigator.js
//  Apne existing Navigator mein yeh screens add karo
// ─────────────────────────────────────────────
import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import BrowseJobsScreen from './screens/BrowseJobsScreen';
import PostJobScreen    from './screens/PostJobScreen';
import ApplyJobScreen   from './screens/ApplyJobScreen';
import MyJobsScreen     from './screens/MyJobsScreen';

const Stack = createNativeStackNavigator();

export default function VidXJobsNavigator() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="BrowseJobs" component={BrowseJobsScreen}/>
      <Stack.Screen name="PostJob"    component={PostJobScreen}/>
      <Stack.Screen name="ApplyJob"   component={ApplyJobScreen}/>
      <Stack.Screen name="MyJobs"     component={MyJobsScreen}/>
    </Stack.Navigator>
  );
}

// ─────────────────────────────────────────────
//  APNE MAIN NAVIGATOR MEIN AISE ADD KARO:
// ─────────────────────────────────────────────
//
//  import VidXJobsNavigator from './VidXJobsNavigator';
//
//  <Stack.Screen
//    name="Jobs"
//    component={VidXJobsNavigator}
//    options={{ headerShown: false }}
//  />
//
//  Fir kisi bhi screen se navigate karo:
//  navigation.navigate('Jobs')  ← Jobs tab kholega
// ─────────────────────────────────────────────
