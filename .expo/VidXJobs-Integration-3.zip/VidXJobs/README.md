# 🎬 VID-X Jobs — React Native Integration Guide

## 📁 Folder Structure
```
VidXJobs/
├── VidXJobsNavigator.js       ← Main navigator (apne app mein add karo)
├── screens/
│   ├── theme.js               ← Colors (VID-X style)
│   ├── BrowseJobsScreen.js    ← Job feed — users yahan dekhte hain
│   ├── PostJobScreen.js       ← Recruiter job post karta hai
│   ├── ApplyJobScreen.js      ← User apply karta hai (3 steps + email)
│   └── MyJobsScreen.js        ← Recruiter PIN se login → apni jobs delete kare
└── utils/
    ├── jobStorage.js          ← AsyncStorage CRUD
    └── sendEmail.js           ← EmailJS REST API
```

---

## 📦 Step 1 — Dependencies Install Karo

```bash
npm install @react-native-async-storage/async-storage
npm install @react-navigation/native-stack
```

---

## ⚙️ Step 2 — EmailJS Setup (FREE, 5 min)

1. **emailjs.com** pe jaao → Free account banao
2. **Email Services** → Gmail connect karo → Service ID milega (`service_xxxxxxx`)
3. **Email Templates** → New template banao with these variables:
   ```
   To: {{to_email}}
   Subject: New Application for {{job_title}} — {{applicant_name}}

   Body:
   Hi {{to_name}},

   Ek naya application aaya hai!

   Job: {{job_title}}
   Applicant: {{applicant_name}}
   Email: {{applicant_email}}
   Phone: {{applicant_phone}}
   Experience: {{applicant_experience}}
   Skills: {{applicant_skills}}
   Portfolio: {{applicant_portfolio}}

   Cover Note:
   {{cover_note}}

   Applied On: {{applied_on}}
   ```
4. Template ID copy karo (`template_xxxxxxx`)
5. **Account → API Keys** → Public Key copy karo (`user_xxxxxxx`)
6. Teen IDs `utils/sendEmail.js` mein daalo (line 12-14)

---

## 🔗 Step 3 — Apne App Navigator Mein Add Karo

```javascript
// App.js ya MainNavigator.js mein
import VidXJobsNavigator from './VidXJobs/VidXJobsNavigator';

// Stack ke andar:
<Stack.Screen name="Jobs" component={VidXJobsNavigator} options={{ headerShown: false }}/>
```

Fir kisi bhi button/tab se navigate karo:
```javascript
navigation.navigate('Jobs')
```

---

## 🔐 PIN System Kaise Kaam Karta Hai

| Action | Kaun kar sakta hai |
|--------|-------------------|
| Job browse karna | Koi bhi |
| Job apply karna | Koi bhi |
| Job post karna | Koi bhi (recruiter) |
| Job delete karna | **Sirf wahi jo PIN jaanta hai** |

- Recruiter job post karte waqt **4-digit PIN** set karta hai
- "My Jobs" tab → PIN enter karo → sirf wahi jobs dikhengi jinka PIN match kare
- Delete button → Confirm alert → Job remove ho jaati hai

---

## 📧 Email Flow

```
User applies
     ↓
ApplyJobScreen → sendApplicationEmail()
     ↓
EmailJS REST API
     ↓
📨 Recruiter ke Gmail pe email aata hai
   (name, email, phone, skills, portfolio, cover note — sab kuch)
```

---

## 🎨 Colors Customize Karna

`screens/theme.js` mein apne brand colors daalo:
```javascript
export const C = {
  pink:   '#ff2d78',  // ← apna primary color
  purple: '#a855f7',
  cyan:   '#00d4ff',
  bg:     '#08080f',  // ← background
  ...
};
```
