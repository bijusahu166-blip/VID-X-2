// ─────────────────────────────────────────────
//  utils/jobStorage.js
//  AsyncStorage se jobs save/load karna
// ─────────────────────────────────────────────
import AsyncStorage from '@react-native-async-storage/async-storage';

const JOBS_KEY = '@vidx_jobs';

export async function loadJobs() {
  try {
    const raw = await AsyncStorage.getItem(JOBS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch { return []; }
}

export async function saveJobs(jobs) {
  try {
    await AsyncStorage.setItem(JOBS_KEY, JSON.stringify(jobs));
  } catch (e) { console.error('saveJobs error', e); }
}

export async function addJob(job) {
  const jobs = await loadJobs();
  const updated = [job, ...jobs];
  await saveJobs(updated);
  return updated;
}

export async function removeJob(jobId, pin) {
  const jobs = await loadJobs();
  const target = jobs.find(j => j.id === jobId);
  if (!target) return { success: false, reason: 'Job nahi mili' };
  if (target.pin !== pin) return { success: false, reason: 'Galat PIN' };
  const updated = jobs.filter(j => j.id !== jobId);
  await saveJobs(updated);
  return { success: true, jobs: updated };
}

export async function getMyJobs(pin) {
  const jobs = await loadJobs();
  return jobs.filter(j => j.pin === pin);
}
