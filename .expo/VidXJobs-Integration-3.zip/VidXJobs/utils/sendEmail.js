// ─────────────────────────────────────────────
//  utils/sendEmail.js
//  EmailJS REST API — works in React Native
//  Setup: https://emailjs.com (free account)
// ─────────────────────────────────────────────

// 🔧 APNA CONFIG YAHAN DAALO (emailjs.com se milega)
const EMAILJS_SERVICE_ID  = 'service_xxxxxxx';   // aapka Service ID
const EMAILJS_TEMPLATE_ID = 'template_xxxxxxx';  // aapka Template ID
const EMAILJS_PUBLIC_KEY  = 'user_xxxxxxxxxxxxxxx'; // aapka Public Key

/**
 * Recruiter ke Gmail pe application email bhejta hai.
 * @param {object} job        - job object (title, company, recruiterEmail)
 * @param {object} applicant  - applicant info (name, email, phone, etc.)
 * @returns {Promise<boolean>} - true = success, false = failed
 */
export async function sendApplicationEmail(job, applicant) {
  // Job-specific credentials use karo agar available ho,
  // warna global config use karo
  const serviceId  = job.ejsService  || EMAILJS_SERVICE_ID;
  const templateId = job.ejsTemplate || EMAILJS_TEMPLATE_ID;
  const publicKey  = job.ejsPubkey   || EMAILJS_PUBLIC_KEY;

  if (!serviceId || !templateId || !publicKey ||
      serviceId.includes('xxx') || publicKey.includes('xxx')) {
    console.warn('[sendEmail] EmailJS credentials set nahi hain.');
    return false;
  }

  const payload = {
    service_id:  serviceId,
    template_id: templateId,
    user_id:     publicKey,
    template_params: {
      to_email:             job.recruiterEmail,
      to_name:              job.company,
      job_title:            job.title,
      applicant_name:       applicant.name,
      applicant_email:      applicant.email,
      applicant_phone:      applicant.phone,
      applicant_experience: applicant.experience || 'Not mentioned',
      applicant_skills:     (applicant.skills || []).join(', ') || 'Not mentioned',
      applicant_portfolio:  applicant.portfolio || 'Not provided',
      cover_note:           applicant.coverNote || 'No cover note',
      applied_on:           new Date().toLocaleString('en-IN'),
    },
  };

  try {
    const res = await fetch('https://api.emailjs.com/api/v1.0/email/send', {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify(payload),
    });
    if (res.status === 200) {
      console.log('[sendEmail] ✅ Email sent to', job.recruiterEmail);
      return true;
    } else {
      const txt = await res.text();
      console.error('[sendEmail] ❌ Failed:', res.status, txt);
      return false;
    }
  } catch (err) {
    console.error('[sendEmail] Network error:', err);
    return false;
  }
}
