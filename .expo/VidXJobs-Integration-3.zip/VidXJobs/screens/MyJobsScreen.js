// ─────────────────────────────────────────────
//  screens/MyJobsScreen.js
//  Recruiter PIN se login karta hai, sirf apni jobs dekh aur delete kar sakta hai
// ─────────────────────────────────────────────
import React, { useState, useRef } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, TextInput,
  StyleSheet, Alert, ActivityIndicator, Animated,
} from 'react-native';
import { getMyJobs, removeJob } from '../utils/jobStorage';
import { C } from './theme';

export default function MyJobsScreen({ navigation }) {
  const [pin, setPin]         = useState(['','','','']);
  const [error, setError]     = useState('');
  const [loading, setLoading] = useState(false);
  const [myJobs, setMyJobs]   = useState(null); // null = not logged in yet
  const [enteredPin, setEnteredPin] = useState('');
  const pinRefs = [useRef(), useRef(), useRef(), useRef()];

  // ── PIN LOGIN ──
  const handlePinChange = (val, idx) => {
    const cleaned = val.replace(/\D/g,'').slice(-1);
    const newPin = [...pin];
    newPin[idx] = cleaned;
    setPin(newPin);
    if (cleaned && idx < 3) pinRefs[idx+1].current?.focus();
    if (!cleaned && idx > 0) pinRefs[idx-1].current?.focus();
  };

  const handleLogin = async () => {
    const fullPin = pin.join('');
    if (fullPin.length < 4) { setError('⚠️ 4-digit PIN poora daalo'); return; }
    setLoading(true); setError('');
    const jobs = await getMyJobs(fullPin);
    setLoading(false);
    if (jobs.length === 0) {
      setError('❌ Galat PIN ya koi job nahi mili');
      setPin(['','','','']);
      pinRefs[0].current?.focus();
      return;
    }
    setEnteredPin(fullPin);
    setMyJobs(jobs);
  };

  // ── DELETE ──
  const handleDelete = (job) => {
    Alert.alert(
      '🗑️ Job Delete Karein?',
      `"${job.title}" permanently delete ho jaayegi. Undo nahi hoga!`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Haan, Delete Karo', style: 'destructive',
          onPress: async () => {
            const result = await removeJob(job.id, enteredPin);
            if (result.success) {
              setMyJobs(prev => prev.filter(j => j.id !== job.id));
              Alert.alert('✅ Deleted', `"${job.title}" remove ho gayi.`);
            } else {
              Alert.alert('❌ Error', result.reason);
            }
          },
        },
      ]
    );
  };

  // ── PIN ENTRY SCREEN ──
  if (myJobs === null) return (
    <View style={styles.root}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Text style={styles.backBtnText}>←</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>My <Text style={{ color: C.pink }}>Jobs</Text></Text>
      </View>

      <View style={styles.loginWrap}>
        <Text style={styles.loginIcon}>🔐</Text>
        <Text style={styles.loginTitle}>Recruiter Login</Text>
        <Text style={styles.loginSub}>
          Apna 4-digit PIN daalo jo aapne{'\n'}job post karte waqt set kiya tha
        </Text>

        {/* 4 PIN boxes */}
        <View style={styles.pinRow}>
          {[0,1,2,3].map(i => (
            <TextInput
              key={i}
              ref={pinRefs[i]}
              style={[styles.pinBox, pin[i] ? styles.pinBoxFilled : {}]}
              value={pin[i]}
              onChangeText={v => handlePinChange(v, i)}
              keyboardType="numeric"
              maxLength={1}
              secureTextEntry
              textAlign="center"
              onKeyPress={({ nativeEvent }) => {
                if (nativeEvent.key === 'Backspace' && !pin[i] && i > 0) {
                  pinRefs[i-1].current?.focus();
                }
              }}
            />
          ))}
        </View>

        {!!error && <Text style={styles.pinError}>{error}</Text>}

        <TouchableOpacity style={styles.loginBtn} onPress={handleLogin} disabled={loading}>
          {loading
            ? <ActivityIndicator color="#fff"/>
            : <Text style={styles.loginBtnText}>🔓 Login Karo</Text>
          }
        </TouchableOpacity>

        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Text style={styles.cancelText}>Cancel</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  // ── MY JOBS LIST ──
  return (
    <View style={styles.root}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Text style={styles.backBtnText}>←</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>My <Text style={{ color: C.pink }}>Jobs</Text></Text>
        <View style={styles.ownerBadge}><Text style={styles.ownerBadgeText}>👑 Recruiter</Text></View>
      </View>

      <ScrollView contentContainerStyle={styles.list}>
        {myJobs.length === 0 ? (
          <View style={styles.emptyBox}>
            <Text style={styles.emptyIcon}>📭</Text>
            <Text style={styles.emptyText}>Saari jobs remove ho gayi hain.</Text>
          </View>
        ) : (
          myJobs.map(job => (
            <View key={job.id} style={styles.card}>
              <View style={styles.cardHeader}>
                <View style={styles.emojiBox}><Text style={styles.emoji}>{job.emoji || '💼'}</Text></View>
                <View style={styles.jobMeta}>
                  <Text style={styles.jobTitle}>{job.title}</Text>
                  <Text style={styles.jobCompany}>{job.company}</Text>
                  <Text style={styles.jobLoc}>📍 {job.location}  ·  🗓 {job.postedAt}</Text>
                </View>
              </View>

              <View style={styles.emailRow}>
                <Text style={styles.emailLabel}>📧 Applications → </Text>
                <Text style={styles.emailVal} numberOfLines={1}>{job.recruiterEmail}</Text>
              </View>

              <TouchableOpacity style={styles.deleteBtn} onPress={() => handleDelete(job)}>
                <Text style={styles.deleteBtnText}>🗑️  Remove This Job</Text>
              </TouchableOpacity>
            </View>
          ))
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root:           { flex: 1, backgroundColor: C.bg },
  header:         { flexDirection: 'row', alignItems: 'center', gap: 12,
                    paddingTop: 54, paddingHorizontal: 18, paddingBottom: 16,
                    borderBottomWidth: 1, borderBottomColor: C.border },
  backBtn:        { width: 38, height: 38, borderRadius: 19,
                    backgroundColor: 'rgba(255,255,255,0.07)',
                    alignItems: 'center', justifyContent: 'center' },
  backBtnText:    { color: '#fff', fontSize: 18 },
  headerTitle:    { fontSize: 22, fontWeight: '800', color: '#fff', flex: 1 },
  ownerBadge:     { backgroundColor: 'rgba(0,212,255,0.1)', borderWidth: 1,
                    borderColor: 'rgba(0,212,255,0.25)', borderRadius: 20,
                    paddingHorizontal: 12, paddingVertical: 5 },
  ownerBadgeText: { color: C.cyan, fontSize: 12, fontWeight: '700' },

  // Login
  loginWrap:      { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 30 },
  loginIcon:      { fontSize: 56, marginBottom: 16 },
  loginTitle:     { fontSize: 24, fontWeight: '800', color: '#fff', marginBottom: 10 },
  loginSub:       { fontSize: 14, color: C.muted, textAlign: 'center', lineHeight: 22, marginBottom: 30 },
  pinRow:         { flexDirection: 'row', gap: 12, marginBottom: 16 },
  pinBox:         { width: 58, height: 64, borderRadius: 14, textAlign: 'center',
                    fontSize: 24, fontWeight: '800', color: '#fff',
                    backgroundColor: 'rgba(255,255,255,0.05)',
                    borderWidth: 2, borderColor: 'rgba(255,255,255,0.12)' },
  pinBoxFilled:   { borderColor: C.pink, backgroundColor: 'rgba(255,45,120,0.1)' },
  pinError:       { color: '#ff6060', fontSize: 13, marginBottom: 16, fontWeight: '600' },
  loginBtn:       { backgroundColor: C.pink, borderRadius: 16, paddingVertical: 14,
                    paddingHorizontal: 50, marginBottom: 14,
                    shadowColor: C.pink, shadowOpacity: 0.4, shadowRadius: 12 },
  loginBtnText:   { color: '#fff', fontWeight: '800', fontSize: 15 },
  cancelText:     { color: C.muted, fontSize: 14, fontWeight: '600' },

  // Jobs list
  list:           { padding: 16, paddingBottom: 60 },
  emptyBox:       { alignItems: 'center', paddingVertical: 60 },
  emptyIcon:      { fontSize: 52, marginBottom: 14 },
  emptyText:      { color: C.muted, fontSize: 15 },
  card:           { backgroundColor: C.card, borderRadius: 20, padding: 18,
                    marginBottom: 14, borderWidth: 1, borderColor: C.border },
  cardHeader:     { flexDirection: 'row', gap: 12, marginBottom: 12 },
  emojiBox:       { width: 50, height: 50, borderRadius: 12, backgroundColor: 'rgba(255,255,255,0.04)',
                    borderWidth: 1, borderColor: C.border, alignItems: 'center', justifyContent: 'center' },
  emoji:          { fontSize: 24 },
  jobMeta:        { flex: 1 },
  jobTitle:       { fontSize: 15, fontWeight: '800', color: '#fff', marginBottom: 2 },
  jobCompany:     { fontSize: 13, color: C.pink, fontWeight: '600', marginBottom: 2 },
  jobLoc:         { fontSize: 11, color: C.muted },
  emailRow:       { flexDirection: 'row', alignItems: 'center', marginBottom: 14,
                    backgroundColor: 'rgba(255,255,255,0.03)', borderRadius: 10,
                    padding: 10, borderWidth: 1, borderColor: 'rgba(255,255,255,0.06)' },
  emailLabel:     { fontSize: 12, color: C.muted },
  emailVal:       { fontSize: 12, color: 'rgba(255,255,255,0.8)', fontWeight: '600', flex: 1 },
  deleteBtn:      { borderWidth: 1, borderColor: 'rgba(255,60,60,0.35)',
                    backgroundColor: 'rgba(255,60,60,0.08)', borderRadius: 12,
                    paddingVertical: 12, alignItems: 'center' },
  deleteBtnText:  { color: '#ff6060', fontSize: 13, fontWeight: '700' },
});
