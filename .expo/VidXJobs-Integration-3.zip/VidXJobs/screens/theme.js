// screens/theme.js — VID-X color tokens
export const C = {
  pink:   '#ff2d78',
  purple: '#a855f7',
  cyan:   '#00d4ff',
  bg:     '#08080f',
  card:   '#111120',
  card2:  '#16162a',
  border: 'rgba(255,255,255,0.08)',
  muted:  'rgba(255,255,255,0.45)',
};
