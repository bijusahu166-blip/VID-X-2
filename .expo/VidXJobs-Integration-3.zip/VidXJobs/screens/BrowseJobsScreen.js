// ─────────────────────────────────────────────
//  screens/BrowseJobsScreen.js
//  VID-X style job feed — users yahan apply karte hain
// ─────────────────────────────────────────────
import React, { useEffect, useState, useCallback } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet,
  ActivityIndicator, RefreshControl, Alert,
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { loadJobs } from '../utils/jobStorage';
import { C } from './theme';

export default function BrowseJobsScreen({ navigation }) {
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const fetchJobs = async () => {
    const data = await loadJobs();
    setJobs(data);
    setLoading(false);
  };

  useFocusEffect(useCallback(() => { fetchJobs(); }, []));

  const onRefresh = async () => { setRefreshing(true); await fetchJobs(); setRefreshing(false); };

  if (loading) return (
    <View style={styles.center}>
      <ActivityIndicator color={C.pink} size="large"/>
    </View>
  );

  return (
    <View style={styles.root}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.logo}>🎬 VID-X Jobs</Text>
        <TouchableOpacity style={styles.myJobsBtn} onPress={() => navigation.navigate('MyJobs')}>
          <Text style={styles.myJobsBtnText}>My Jobs 👑</Text>
        </TouchableOpacity>
      </View>

      <ScrollView
        contentContainerStyle={styles.list}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={C.pink}/>}
        showsVerticalScrollIndicator={false}
      >
        <Text style={styles.pageTitle}>
          Find Your{' '}
          <Text style={styles.grad}>Dream Job</Text>
        </Text>

        {jobs.length === 0 ? (
          <View style={styles.emptyBox}>
            <Text style={styles.emptyIcon}>📭</Text>
            <Text style={styles.emptyText}>Abhi koi job nahi hai.{'\n'}Pehle koi job post karo!</Text>
            <TouchableOpacity style={styles.postNowBtn} onPress={() => navigation.navigate('PostJob')}>
              <Text style={styles.postNowText}>+ Post Job</Text>
            </TouchableOpacity>
          </View>
        ) : (
          jobs.map(job => (
            <JobCard key={job.id} job={job} onApply={() => navigation.navigate('ApplyJob', { job })} />
          ))
        )}
      </ScrollView>

      {/* FAB — Post Job */}
      <TouchableOpacity style={styles.fab} onPress={() => navigation.navigate('PostJob')}>
        <Text style={styles.fabText}>＋ Post Job</Text>
      </TouchableOpacity>
    </View>
  );
}

function JobCard({ job, onApply }) {
  return (
    <View style={styles.card}>
      <View style={styles.cardHeader}>
        <View style={styles.emojiBox}><Text style={styles.emoji}>{job.emoji || '💼'}</Text></View>
        <View style={styles.jobMeta}>
          <Text style={styles.jobTitle}>{job.title}</Text>
          <Text style={styles.jobCompany}>{job.company}</Text>
          <Text style={styles.jobLoc}>📍 {job.location}  ·  🗓 {job.postedAt}</Text>
        </View>
        <View style={styles.hotBadge}><Text style={styles.hotText}>🔥 {job.type}</Text></View>
      </View>

      {/* Badges */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.badgeRow}>
        <View style={styles.salaryBadge}><Text style={styles.salaryText}>💰 {job.salary}</Text></View>
        {(job.tags || []).map(t => (
          <View key={t} style={styles.tagBadge}><Text style={styles.tagText}>{t}</Text></View>
        ))}
      </ScrollView>

      {!!job.description && (
        <Text style={styles.desc} numberOfLines={2}>{job.description}</Text>
      )}

      <TouchableOpacity style={styles.applyBtn} onPress={onApply} activeOpacity={0.85}>
        <Text style={styles.applyBtnText}>Apply Now →</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  root:        { flex: 1, backgroundColor: C.bg },
  center:      { flex: 1, backgroundColor: C.bg, alignItems: 'center', justifyContent: 'center' },
  header:      { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
                 paddingHorizontal: 18, paddingTop: 54, paddingBottom: 14,
                 borderBottomWidth: 1, borderBottomColor: C.border,
                 backgroundColor: 'rgba(8,8,15,0.95)' },
  logo:        { fontSize: 20, fontWeight: '800', color: C.pink },
  myJobsBtn:   { backgroundColor: 'rgba(255,45,120,0.12)', borderWidth: 1,
                 borderColor: 'rgba(255,45,120,0.3)', borderRadius: 20, paddingHorizontal: 14, paddingVertical: 7 },
  myJobsBtnText:{ fontSize: 13, fontWeight: '700', color: '#fff' },
  list:        { padding: 16, paddingBottom: 120 },
  pageTitle:   { fontSize: 24, fontWeight: '800', color: '#fff', marginBottom: 18 },
  grad:        { color: C.pink },

  // Empty
  emptyBox:    { alignItems: 'center', paddingVertical: 60 },
  emptyIcon:   { fontSize: 52, marginBottom: 14 },
  emptyText:   { color: C.muted, fontSize: 15, textAlign: 'center', lineHeight: 22 },
  postNowBtn:  { marginTop: 18, backgroundColor: C.pink, borderRadius: 14,
                 paddingHorizontal: 24, paddingVertical: 12 },
  postNowText: { color: '#fff', fontWeight: '700', fontSize: 14 },

  // Card
  card:        { backgroundColor: C.card, borderRadius: 20, padding: 18,
                 marginBottom: 14, borderWidth: 1, borderColor: C.border },
  cardHeader:  { flexDirection: 'row', gap: 12, marginBottom: 12, alignItems: 'flex-start' },
  emojiBox:    { width: 52, height: 52, borderRadius: 12, backgroundColor: 'rgba(255,255,255,0.04)',
                 borderWidth: 1, borderColor: C.border, alignItems: 'center', justifyContent: 'center' },
  emoji:       { fontSize: 26 },
  jobMeta:     { flex: 1 },
  jobTitle:    { fontSize: 15, fontWeight: '700', color: '#fff', marginBottom: 2 },
  jobCompany:  { fontSize: 13, color: C.pink, fontWeight: '600', marginBottom: 2 },
  jobLoc:      { fontSize: 11, color: C.muted },
  hotBadge:    { backgroundColor: C.pink, borderRadius: 20, paddingHorizontal: 10, paddingVertical: 4, alignSelf: 'flex-start' },
  hotText:     { color: '#fff', fontSize: 10, fontWeight: '700' },

  badgeRow:    { marginBottom: 12 },
  salaryBadge: { backgroundColor: 'rgba(0,212,255,0.1)', borderWidth: 1,
                 borderColor: 'rgba(0,212,255,0.25)', borderRadius: 20,
                 paddingHorizontal: 10, paddingVertical: 4, marginRight: 6 },
  salaryText:  { color: '#00d4ff', fontSize: 11, fontWeight: '600' },
  tagBadge:    { backgroundColor: 'rgba(255,255,255,0.05)', borderWidth: 1,
                 borderColor: C.border, borderRadius: 20,
                 paddingHorizontal: 10, paddingVertical: 4, marginRight: 6 },
  tagText:     { color: C.muted, fontSize: 11 },

  desc:        { fontSize: 13, color: 'rgba(255,255,255,0.5)', lineHeight: 18, marginBottom: 14 },
  applyBtn:    { backgroundColor: C.pink, borderRadius: 14, paddingVertical: 13,
                 alignItems: 'center', shadowColor: C.pink, shadowOpacity: 0.4,
                 shadowRadius: 10, shadowOffset: { width: 0, height: 4 } },
  applyBtnText:{ color: '#fff', fontWeight: '700', fontSize: 14, letterSpacing: 0.3 },

  fab:         { position: 'absolute', bottom: 30, right: 20,
                 backgroundColor: C.purple, borderRadius: 30,
                 paddingHorizontal: 22, paddingVertical: 14,
                 shadowColor: C.purple, shadowOpacity: 0.5, shadowRadius: 12 },
  fabText:     { color: '#fff', fontWeight: '800', fontSize: 14 },
});
