// ─────────────────────────────────────────────
//  screens/ApplyJobScreen.js
//  3-step application form + email to recruiter
// ─────────────────────────────────────────────
import React, { useState } from 'react';
import {
  View, Text, TextInput, ScrollView, TouchableOpacity,
  StyleSheet, ActivityIndicator, Alert, KeyboardAvoidingView,
  Platform, Modal,
} from 'react-native';
import { sendApplicationEmail } from '../utils/sendEmail';
import { C } from './theme';

const SKILLS = [
  'Video Editing','Reels','Music Production','Gaming','Vlogging',
  'Animation','Live Streaming','Thumbnail Design','Scriptwriting','Photography',
];
const EXPERIENCE_OPTIONS = [
  'Fresher (0–1 yr)','Junior (1–3 yrs)','Mid-level (3–5 yrs)','Senior (5+ yrs)',
];

export default function ApplyJobScreen({ route, navigation }) {
  const { job } = route.params;

  const [step, setStep]       = useState(1);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [showExpPicker, setShowExpPicker] = useState(false);

  // Form state
  const [name, setName]             = useState('');
  const [email, setEmail]           = useState('');
  const [phone, setPhone]           = useState('');
  const [experience, setExperience] = useState('');
  const [skills, setSkills]         = useState([]);
  const [portfolio, setPortfolio]   = useState('');
  const [coverNote, setCoverNote]   = useState('');

  const toggleSkill = (s) =>
    setSkills(prev => prev.includes(s) ? prev.filter(x => x !== s) : [...prev, s]);

  const nextStep = () => {
    if (step === 1) {
      if (!name.trim() || !email.trim() || !phone.trim()) {
        Alert.alert('⚠️ Zaroori fields', 'Name, Email aur Phone daalna zaroori hai!'); return;
      }
    }
    setStep(s => s + 1);
  };
  const prevStep = () => setStep(s => s - 1);

  const handleSubmit = async () => {
    setLoading(true);
    const applicant = { name, email, phone, experience, skills, portfolio, coverNote };
    const sent = await sendApplicationEmail(job, applicant);
    setLoading(false);
    setSuccess(true);
    // Email status shown in success screen
    // 'sent' = true means email gaya, false = credentials missing (still show success UI)
    console.log('Email sent:', sent);
  };

  // ── SUCCESS SCREEN ──
  if (success) return (
    <View style={styles.root}>
      <View style={styles.successWrap}>
        <Text style={styles.successIcon}>🎉</Text>
        <Text style={styles.successTitle}>Application Bheji!</Text>
        <Text style={styles.successSub}>
          <Text style={{ color: C.pink, fontWeight: '700' }}>{job.company}</Text> ko aapki application{'\n'}
          mil gayi. 3 din mein reply milega.
        </Text>
        <View style={styles.emailBadge}>
          <Text style={styles.emailBadgeText}>📧 Email recruiter ko ja chuka hai</Text>
        </View>
        <View style={styles.summaryCard}>
          <SRow label="Naam" value={name}/>
          <SRow label="Email" value={email}/>
          <SRow label="Phone" value={phone}/>
          <SRow label="Skills" value={skills.join(', ') || '—'}/>
        </View>
        <TouchableOpacity style={styles.doneBtn} onPress={() => navigation.goBack()}>
          <Text style={styles.doneBtnText}>Done ✓</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <KeyboardAvoidingView style={styles.root} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Text style={styles.backBtnText}>←</Text>
        </TouchableOpacity>
        <View style={styles.headerInfo}>
          <Text style={styles.headerLabel}>Apply Now</Text>
          <Text style={styles.headerJob}>{job.emoji} {job.title}</Text>
          <Text style={styles.headerCo}>{job.company}</Text>
        </View>
      </View>

      {/* Step bar */}
      <View style={styles.stepBar}>
        {[1,2,3].map((n,i) => (
          <React.Fragment key={n}>
            <View style={[styles.stepDot, step >= n && styles.stepDotActive]}>
              <Text style={[styles.stepDotText, step >= n && styles.stepDotTextActive]}>
                {step > n ? '✓' : n}
              </Text>
            </View>
            {i < 2 && <View style={[styles.stepLine, step > n && styles.stepLineDone]}/>}
          </React.Fragment>
        ))}
      </View>
      <View style={styles.stepLabels}>
        {['Profile','Skills','Submit'].map(l => (
          <Text key={l} style={styles.stepLabel}>{l}</Text>
        ))}
      </View>

      <ScrollView contentContainerStyle={styles.body} keyboardShouldPersistTaps="handled">

        {/* ── STEP 1 ── */}
        {step === 1 && (
          <View>
            <Text style={styles.sectionTitle}>👤 Aapki Profile</Text>
            <Field label="Full Name *" value={name} onChangeText={setName} placeholder="Rahul Sharma"/>
            <Field label="Email *" value={email} onChangeText={setEmail} placeholder="rahul@gmail.com" keyboardType="email-address"/>
            <Field label="Phone *" value={phone} onChangeText={setPhone} placeholder="+91 98765 43210" keyboardType="phone-pad"/>

            {/* Experience picker */}
            <Text style={styles.fieldLabel}>Experience</Text>
            <TouchableOpacity style={styles.picker} onPress={() => setShowExpPicker(true)}>
              <Text style={[styles.pickerText, !experience && { color: C.muted }]}>
                {experience || 'Select experience...'}
              </Text>
              <Text style={{ color: C.muted }}>▾</Text>
            </TouchableOpacity>

            <Modal visible={showExpPicker} transparent animationType="slide">
              <TouchableOpacity style={styles.modalBg} activeOpacity={1} onPress={() => setShowExpPicker(false)}>
                <View style={styles.pickerSheet}>
                  <View style={styles.pickerHandle}/>
                  <Text style={styles.pickerTitle}>Experience Select Karo</Text>
                  {EXPERIENCE_OPTIONS.map(opt => (
                    <TouchableOpacity key={opt} style={styles.pickerOption}
                      onPress={() => { setExperience(opt); setShowExpPicker(false); }}>
                      <Text style={[styles.pickerOptionText, experience===opt && { color: C.pink, fontWeight:'700' }]}>{opt}</Text>
                      {experience===opt && <Text style={{ color: C.pink }}>✓</Text>}
                    </TouchableOpacity>
                  ))}
                </View>
              </TouchableOpacity>
            </Modal>
          </View>
        )}

        {/* ── STEP 2 ── */}
        {step === 2 && (
          <View>
            <Text style={styles.sectionTitle}>⚡ Skills & Portfolio</Text>
            <Text style={styles.hint}>Apne skills select karo (multiple ho sakti hain)</Text>
            <View style={styles.chipGrid}>
              {SKILLS.map(s => (
                <TouchableOpacity key={s} style={[styles.chip, skills.includes(s) && styles.chipOn]}
                  onPress={() => toggleSkill(s)}>
                  <Text style={[styles.chipText, skills.includes(s) && styles.chipTextOn]}>
                    {skills.includes(s) ? '✓ ' : ''}{s}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
            <Field label="Portfolio / Channel Link" value={portfolio} onChangeText={setPortfolio}
              placeholder="https://youtube.com/@channel" keyboardType="url"/>
          </View>
        )}

        {/* ── STEP 3 ── */}
        {step === 3 && (
          <View>
            <Text style={styles.sectionTitle}>✍️ Cover Note</Text>
            <Text style={styles.hint}>VID-X ko kyun hire karna chahiye aapko?</Text>
            <TextInput
              style={[styles.input, { height: 110, textAlignVertical: 'top' }]}
              value={coverNote} onChangeText={setCoverNote} multiline
              placeholder="Main passionate hoon video content mein aur..."
              placeholderTextColor={C.muted}
            />

            {/* Summary */}
            <View style={styles.summaryCard}>
              <Text style={styles.summaryTitle}>📋 Application Summary</Text>
              <SRow label="Naam" value={name}/>
              <SRow label="Email" value={email}/>
              <SRow label="Phone" value={phone}/>
              <SRow label="Experience" value={experience || '—'}/>
              <SRow label="Skills" value={skills.join(', ') || '—'}/>
              <SRow label="Portfolio" value={portfolio || '—'}/>
            </View>

            <View style={styles.emailNote}>
              <Text style={styles.emailNoteText}>
                📧 Apply karte hi recruiter{'\n'}
                <Text style={{ color: C.pink, fontWeight: '700' }}>{job.recruiterEmail}</Text>
                {'\n'}ko email jaayegi
              </Text>
            </View>
          </View>
        )}

        {/* Nav buttons */}
        <View style={styles.navRow}>
          {step > 1 && (
            <TouchableOpacity style={styles.backNavBtn} onPress={prevStep}>
              <Text style={styles.backNavText}>← Back</Text>
            </TouchableOpacity>
          )}
          {step < 3 ? (
            <TouchableOpacity style={[styles.nextBtn, step===1 && { flex: 1 }]} onPress={nextStep}>
              <Text style={styles.nextBtnText}>Next →</Text>
            </TouchableOpacity>
          ) : (
            <TouchableOpacity style={styles.submitBtn} onPress={handleSubmit} disabled={loading}>
              {loading
                ? <ActivityIndicator color="#fff"/>
                : <Text style={styles.submitBtnText}>🚀 Submit Application</Text>
              }
            </TouchableOpacity>
          )}
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

// ── Helper Components ──
function Field({ label, value, onChangeText, placeholder, keyboardType = 'default' }) {
  return (
    <View style={{ marginBottom: 14 }}>
      <Text style={styles.fieldLabel}>{label}</Text>
      <TextInput style={styles.input} value={value} onChangeText={onChangeText}
        placeholder={placeholder} placeholderTextColor={C.muted}
        keyboardType={keyboardType} autoCapitalize="none"/>
    </View>
  );
}
function SRow({ label, value }) {
  return (
    <View style={styles.sRow}>
      <Text style={styles.sKey}>{label}</Text>
      <Text style={styles.sVal} numberOfLines={2}>{value || '—'}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  root:           { flex: 1, backgroundColor: C.bg },
  header:         { flexDirection: 'row', gap: 14, alignItems: 'center',
                    paddingTop: 54, paddingHorizontal: 18, paddingBottom: 16,
                    borderBottomWidth: 1, borderBottomColor: C.border },
  backBtn:        { width: 38, height: 38, borderRadius: 19, backgroundColor: 'rgba(255,255,255,0.07)',
                    alignItems: 'center', justifyContent: 'center' },
  backBtnText:    { color: '#fff', fontSize: 18 },
  headerInfo:     { flex: 1 },
  headerLabel:    { fontSize: 11, color: C.muted, fontWeight: '600', textTransform: 'uppercase', letterSpacing: 1 },
  headerJob:      { fontSize: 16, fontWeight: '800', color: '#fff', marginTop: 2 },
  headerCo:       { fontSize: 12, color: C.pink, fontWeight: '600' },

  stepBar:        { flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
                    paddingHorizontal: 40, paddingTop: 20, gap: 0 },
  stepDot:        { width: 30, height: 30, borderRadius: 15,
                    backgroundColor: 'rgba(255,255,255,0.07)',
                    borderWidth: 2, borderColor: 'rgba(255,255,255,0.15)',
                    alignItems: 'center', justifyContent: 'center' },
  stepDotActive:  { backgroundColor: C.pink, borderColor: C.pink },
  stepDotText:    { color: 'rgba(255,255,255,0.3)', fontSize: 11, fontWeight: '700' },
  stepDotTextActive:{ color: '#fff' },
  stepLine:       { flex: 1, height: 2, backgroundColor: 'rgba(255,255,255,0.1)', marginHorizontal: 4 },
  stepLineDone:   { backgroundColor: C.pink },
  stepLabels:     { flexDirection: 'row', justifyContent: 'space-around', paddingHorizontal: 20, marginTop: 6, marginBottom: 4 },
  stepLabel:      { fontSize: 10, color: C.muted, fontWeight: '600' },

  body:           { padding: 18, paddingBottom: 60 },
  sectionTitle:   { fontSize: 17, fontWeight: '800', color: '#fff', marginBottom: 16 },
  hint:           { fontSize: 12, color: C.muted, marginBottom: 14, marginTop: -10 },
  fieldLabel:     { fontSize: 11, color: C.muted, fontWeight: '700', textTransform: 'uppercase',
                    letterSpacing: 0.6, marginBottom: 6 },
  input:          { backgroundColor: 'rgba(255,255,255,0.05)', borderWidth: 1,
                    borderColor: 'rgba(255,255,255,0.1)', borderRadius: 12,
                    paddingHorizontal: 14, paddingVertical: 12, color: '#fff', fontSize: 14,
                    marginBottom: 14 },
  picker:         { backgroundColor: 'rgba(255,255,255,0.05)', borderWidth: 1,
                    borderColor: 'rgba(255,255,255,0.1)', borderRadius: 12,
                    paddingHorizontal: 14, paddingVertical: 13, flexDirection: 'row',
                    justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 },
  pickerText:     { color: '#fff', fontSize: 14 },

  // Experience Modal
  modalBg:        { flex: 1, backgroundColor: 'rgba(0,0,0,0.7)', justifyContent: 'flex-end' },
  pickerSheet:    { backgroundColor: '#1a1a2e', borderRadius: 24, padding: 20, paddingBottom: 40 },
  pickerHandle:   { width: 40, height: 4, backgroundColor: 'rgba(255,255,255,0.2)',
                    borderRadius: 2, alignSelf: 'center', marginBottom: 16 },
  pickerTitle:    { color: C.muted, fontSize: 12, fontWeight: '700', textTransform: 'uppercase',
                    letterSpacing: 1, marginBottom: 14 },
  pickerOption:   { paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: 'rgba(255,255,255,0.06)',
                    flexDirection: 'row', justifyContent: 'space-between' },
  pickerOptionText:{ color: '#fff', fontSize: 15 },

  // Skills
  chipGrid:       { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 18 },
  chip:           { paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20,
                    backgroundColor: 'rgba(255,255,255,0.04)',
                    borderWidth: 1, borderColor: 'rgba(255,255,255,0.1)' },
  chipOn:         { backgroundColor: 'rgba(255,45,120,0.2)', borderColor: C.pink },
  chipText:       { color: 'rgba(255,255,255,0.6)', fontSize: 12, fontWeight: '500' },
  chipTextOn:     { color: '#fff', fontWeight: '700' },

  // Summary
  summaryCard:    { backgroundColor: 'rgba(255,255,255,0.03)', borderWidth: 1,
                    borderColor: 'rgba(255,255,255,0.08)', borderRadius: 14, padding: 16, marginBottom: 16 },
  summaryTitle:   { fontSize: 11, color: C.muted, fontWeight: '700', textTransform: 'uppercase',
                    letterSpacing: 0.5, marginBottom: 12 },
  sRow:           { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8, gap: 10 },
  sKey:           { fontSize: 12, color: C.muted, flexShrink: 0 },
  sVal:           { fontSize: 12, color: 'rgba(255,255,255,0.85)', textAlign: 'right', flex: 1 },

  emailNote:      { backgroundColor: 'rgba(0,212,255,0.07)', borderWidth: 1,
                    borderColor: 'rgba(0,212,255,0.2)', borderRadius: 12, padding: 14,
                    marginBottom: 8, alignItems: 'center' },
  emailNoteText:  { color: 'rgba(0,212,255,0.9)', fontSize: 13, textAlign: 'center', lineHeight: 20 },

  // Nav buttons
  navRow:         { flexDirection: 'row', gap: 10, marginTop: 10 },
  backNavBtn:     { flex: 1, backgroundColor: 'rgba(255,255,255,0.06)', borderWidth: 1,
                    borderColor: 'rgba(255,255,255,0.12)', borderRadius: 14,
                    paddingVertical: 13, alignItems: 'center' },
  backNavText:    { color: 'rgba(255,255,255,0.7)', fontSize: 14, fontWeight: '600' },
  nextBtn:        { flex: 2, backgroundColor: C.pink, borderRadius: 14,
                    paddingVertical: 13, alignItems: 'center' },
  nextBtnText:    { color: '#fff', fontWeight: '700', fontSize: 14 },
  submitBtn:      { flex: 2, backgroundColor: C.pink, borderRadius: 14,
                    paddingVertical: 13, alignItems: 'center' },
  submitBtnText:  { color: '#fff', fontWeight: '700', fontSize: 14 },

  // Success
  successWrap:    { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 30 },
  successIcon:    { fontSize: 64, marginBottom: 16 },
  successTitle:   { fontSize: 26, fontWeight: '800', color: '#fff', marginBottom: 10 },
  successSub:     { fontSize: 14, color: C.muted, textAlign: 'center', lineHeight: 22, marginBottom: 20 },
  emailBadge:     { backgroundColor: 'rgba(0,212,255,0.1)', borderWidth: 1,
                    borderColor: 'rgba(0,212,255,0.25)', borderRadius: 20,
                    paddingHorizontal: 18, paddingVertical: 8, marginBottom: 24 },
  emailBadgeText: { color: '#00d4ff', fontSize: 13, fontWeight: '600' },
  doneBtn:        { backgroundColor: C.pink, borderRadius: 14, paddingHorizontal: 40,
                    paddingVertical: 14, marginTop: 10 },
  doneBtnText:    { color: '#fff', fontWeight: '800', fontSize: 15 },
});
