// ─────────────────────────────────────────────
//  screens/PostJobScreen.js
//  Recruiter job post karta hai + PIN set karta hai
// ─────────────────────────────────────────────
import React, { useState } from 'react';
import {
  View, Text, TextInput, ScrollView, TouchableOpacity,
  StyleSheet, Alert, ActivityIndicator, KeyboardAvoidingView, Platform,
} from 'react-native';
import { addJob } from '../utils/jobStorage';
import { C } from './theme';

const JOB_TYPES = ['Full-time','Part-time','Freelance','Internship'];

export default function PostJobScreen({ navigation }) {
  const [loading, setLoading]     = useState(false);

  // EmailJS config
  const [pubkey, setPubkey]       = useState('');
  const [service, setService]     = useState('');
  const [template, setTemplate]   = useState('');

  // Security
  const [pin, setPin]             = useState('');

  // Job details
  const [title, setTitle]         = useState('');
  const [company, setCompany]     = useState('');
  const [recruiterEmail, setRecruiterEmail] = useState('');
  const [location, setLocation]   = useState('');
  const [salary, setSalary]       = useState('');
  const [type, setType]           = useState('Full-time');
  const [emoji, setEmoji]         = useState('');
  const [description, setDescription] = useState('');
  const [tags, setTags]           = useState('');

  const handlePost = async () => {
    if (!title.trim() || !company.trim() || !recruiterEmail.trim()) {
      Alert.alert('⚠️ Zaroori fields', 'Job Title, Company aur Email zaroori hain!'); return;
    }
    if (!/^\d{4}$/.test(pin)) {
      Alert.alert('⚠️ PIN', '4-digit numeric PIN set karo (e.g. 1234)'); return;
    }

    setLoading(true);
    const job = {
      id:             Date.now(),
      title:          title.trim(),
      company:        company.trim(),
      recruiterEmail: recruiterEmail.trim(),
      pin,
      location:       location || 'Remote',
      salary:         salary || 'Negotiable',
      type,
      emoji:          emoji || '💼',
      description:    description.trim(),
      tags:           tags.split(',').map(t => t.trim()).filter(Boolean),
      ejsPubkey:      pubkey.trim(),
      ejsService:     service.trim(),
      ejsTemplate:    template.trim(),
      postedAt:       new Date().toLocaleDateString('en-IN'),
    };

    await addJob(job);
    setLoading(false);
    Alert.alert('✅ Job Posted!', `"${title}" ab live hai!`, [
      { text: 'OK', onPress: () => navigation.goBack() },
    ]);
  };

  return (
    <KeyboardAvoidingView style={styles.root} behavior={Platform.OS==='ios'?'padding':undefined}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Text style={styles.backBtnText}>←</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Post a <Text style={{ color: C.pink }}>Job</Text></Text>
      </View>

      <ScrollView contentContainerStyle={styles.body} keyboardShouldPersistTaps="handled">

        {/* EmailJS Notice */}
        <View style={styles.notice}>
          <Text style={styles.noticeText}>
            ⚙️ Real email ke liye EmailJS credentials daalo.{'\n'}
            Free account: <Text style={{ color: C.cyan }}>emailjs.com</Text>
          </Text>
        </View>

        <SectionTitle>📧 Email Config (EmailJS)</SectionTitle>
        <Field label="Public Key" value={pubkey} onChangeText={setPubkey} placeholder="user_xxxxxxxxxxxxxxx"/>
        <Field label="Service ID" value={service} onChangeText={setService} placeholder="service_xxxxxxx"/>
        <Field label="Template ID" value={template} onChangeText={setTemplate} placeholder="template_xxxxxxx"/>

        <SectionTitle>🔐 Security PIN</SectionTitle>
        <Text style={styles.pinHint}>Yeh PIN sirf aap jaanoge — iske bina koi job delete nahi kar sakta</Text>
        <TextInput
          style={[styles.input, styles.pinInput]}
          value={pin} onChangeText={t => setPin(t.replace(/\D/g,'').slice(0,4))}
          placeholder="4-digit PIN" placeholderTextColor={C.muted}
          keyboardType="numeric" maxLength={4} secureTextEntry
        />

        <SectionTitle>🏢 Job Details</SectionTitle>
        <Field label="Job Title *" value={title} onChangeText={setTitle} placeholder="Video Content Creator"/>
        <Field label="Company Name *" value={company} onChangeText={setCompany} placeholder="VID-X Studios"/>
        <Field label="Your Gmail (applications yahan aayenge) *"
          value={recruiterEmail} onChangeText={setRecruiterEmail}
          placeholder="recruiter@gmail.com" keyboardType="email-address"/>
        <Field label="Location" value={location} onChangeText={setLocation} placeholder="Remote · India"/>
        <Field label="Salary Range" value={salary} onChangeText={setSalary} placeholder="₹25K – ₹60K/mo"/>
        <Field label="Job Emoji" value={emoji} onChangeText={setEmoji} placeholder="🎬"/>

        {/* Job Type Selector */}
        <Text style={styles.fieldLabel}>Job Type</Text>
        <View style={styles.typeRow}>
          {JOB_TYPES.map(t => (
            <TouchableOpacity key={t} style={[styles.typeChip, type===t && styles.typeChipOn]}
              onPress={() => setType(t)}>
              <Text style={[styles.typeText, type===t && styles.typeTextOn]}>{t}</Text>
            </TouchableOpacity>
          ))}
        </View>

        <Text style={styles.fieldLabel}>Description</Text>
        <TextInput style={[styles.input, { height: 90, textAlignVertical:'top', marginBottom:14 }]}
          value={description} onChangeText={setDescription} multiline
          placeholder="Job ke baare mein likho..." placeholderTextColor={C.muted}/>

        <Field label="Tags (comma separated)" value={tags} onChangeText={setTags} placeholder="Reels, Music, Editing"/>

        <TouchableOpacity style={styles.postBtn} onPress={handlePost} disabled={loading}>
          {loading
            ? <ActivityIndicator color="#fff"/>
            : <Text style={styles.postBtnText}>🚀 Post Job Now</Text>
          }
        </TouchableOpacity>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

function SectionTitle({ children }) {
  return <Text style={styles.sectionTitle}>{children}</Text>;
}
function Field({ label, value, onChangeText, placeholder, keyboardType='default' }) {
  return (
    <View style={{ marginBottom: 14 }}>
      <Text style={styles.fieldLabel}>{label}</Text>
      <TextInput style={styles.input} value={value} onChangeText={onChangeText}
        placeholder={placeholder} placeholderTextColor={C.muted}
        keyboardType={keyboardType} autoCapitalize="none"/>
    </View>
  );
}

const styles = StyleSheet.create({
  root:         { flex: 1, backgroundColor: C.bg },
  header:       { flexDirection: 'row', alignItems: 'center', gap: 14,
                  paddingTop: 54, paddingHorizontal: 18, paddingBottom: 16,
                  borderBottomWidth: 1, borderBottomColor: C.border },
  backBtn:      { width: 38, height: 38, borderRadius: 19,
                  backgroundColor: 'rgba(255,255,255,0.07)',
                  alignItems: 'center', justifyContent: 'center' },
  backBtnText:  { color: '#fff', fontSize: 18 },
  headerTitle:  { fontSize: 22, fontWeight: '800', color: '#fff' },
  body:         { padding: 18, paddingBottom: 60 },

  notice:       { backgroundColor: 'rgba(255,180,0,0.08)', borderWidth: 1,
                  borderColor: 'rgba(255,180,0,0.2)', borderRadius: 12,
                  padding: 14, marginBottom: 20 },
  noticeText:   { color: 'rgba(255,200,80,0.9)', fontSize: 13, lineHeight: 20 },

  sectionTitle: { fontSize: 13, fontWeight: '800', color: C.muted,
                  textTransform: 'uppercase', letterSpacing: 1,
                  borderBottomWidth: 1, borderBottomColor: C.border,
                  paddingBottom: 8, marginTop: 20, marginBottom: 14 },
  fieldLabel:   { fontSize: 11, color: C.muted, fontWeight: '700',
                  textTransform: 'uppercase', letterSpacing: 0.6, marginBottom: 6 },
  input:        { backgroundColor: 'rgba(255,255,255,0.05)', borderWidth: 1,
                  borderColor: 'rgba(255,255,255,0.1)', borderRadius: 12,
                  paddingHorizontal: 14, paddingVertical: 12, color: '#fff', fontSize: 14 },
  pinHint:      { fontSize: 12, color: C.muted, marginBottom: 10, lineHeight: 18 },
  pinInput:     { letterSpacing: 10, fontSize: 20, fontWeight: '800', marginBottom: 14 },

  typeRow:      { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 14 },
  typeChip:     { paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20,
                  backgroundColor: 'rgba(255,255,255,0.04)',
                  borderWidth: 1, borderColor: 'rgba(255,255,255,0.1)' },
  typeChipOn:   { backgroundColor: 'rgba(255,45,120,0.2)', borderColor: C.pink },
  typeText:     { color: C.muted, fontSize: 13, fontWeight: '600' },
  typeTextOn:   { color: '#fff' },

  postBtn:      { backgroundColor: C.cyan, borderRadius: 14, paddingVertical: 15,
                  alignItems: 'center', marginTop: 10,
                  shadowColor: C.cyan, shadowOpacity: 0.3, shadowRadius: 12 },
  postBtnText:  { color: '#fff', fontWeight: '800', fontSize: 15, letterSpacing: 0.3 },
});
